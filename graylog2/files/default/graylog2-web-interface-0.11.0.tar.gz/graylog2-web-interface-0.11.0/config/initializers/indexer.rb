Tire.configure do
  url(Configuration.indexer_host)
end
