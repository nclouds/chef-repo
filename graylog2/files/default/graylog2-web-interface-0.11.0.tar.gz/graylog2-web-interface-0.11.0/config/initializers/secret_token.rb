# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Graylog2WebInterface::Application.config.secret_token = 'd826e9b13d3505bac8997c0eca5c14249f93323551549884e157eee4abcac8847c1db8bea967334cb4461b9d241454870646ec0eddf6ebfd9e1874183d53a603'
