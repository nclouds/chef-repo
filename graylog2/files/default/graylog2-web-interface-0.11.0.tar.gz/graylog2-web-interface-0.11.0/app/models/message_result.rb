class MessageResult < Array

  attr_accessor :total_result_count, :used_indices

end
