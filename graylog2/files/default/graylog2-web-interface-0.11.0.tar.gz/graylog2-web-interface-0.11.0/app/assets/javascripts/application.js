// This is a manifest file that'll be compiled into application, which will include all the files
// listed below.
//
// Any JavaScript/Coffee file within this directory, lib/assets/javascripts, vendor/assets/javascripts,
// or vendor/assets/javascripts of plugins, if any, can be referenced here using a relative path.
//
// It's not advisable to add code directly here, but if you do, it'll appear at the bottom of the
// the compiled file.
//
// WARNING: THE FIRST BLANK LINE MARKS THE END OF WHAT'S TO BE PROCESSED, ANY BLANK LINE SHOULD
// GO AFTER THE REQUIRES BELOW.
//
//= require files/jquery-1.8.1
//= require files/rails
//= require files/master
//= require files/jquery.autocomplete.min
//= require files/jquery.gritter.min
//= require files/jquery.mapkey.min
//= require files/jquery.numeric
//= require files/jquery.simplemodal.min
//= require files/jquery.sparkline.min
