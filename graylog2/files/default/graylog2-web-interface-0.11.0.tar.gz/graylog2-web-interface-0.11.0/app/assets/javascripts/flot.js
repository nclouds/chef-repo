//= require files/jquery.flot.min
//= require files/jquery.flot.resize.min
//= require files/jquery.flot.selection.min