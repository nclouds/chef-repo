class AlarmSettingsController < ApplicationController

  def index
  	
  end

end