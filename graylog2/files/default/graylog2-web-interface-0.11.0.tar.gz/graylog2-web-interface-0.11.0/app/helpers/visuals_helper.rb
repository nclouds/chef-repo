module VisualsHelper
end
