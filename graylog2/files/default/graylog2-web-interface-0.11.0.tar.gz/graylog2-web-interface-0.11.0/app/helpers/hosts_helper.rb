module HostsHelper

end
