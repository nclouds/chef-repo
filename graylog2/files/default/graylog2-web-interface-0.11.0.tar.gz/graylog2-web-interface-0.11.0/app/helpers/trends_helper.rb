module TrendsHelper
end
