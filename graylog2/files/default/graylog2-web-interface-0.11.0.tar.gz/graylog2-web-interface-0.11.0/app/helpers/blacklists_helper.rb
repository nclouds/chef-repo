module BlacklistsHelper
end
